package crypto.msd117c.com.cryptocurrency.di

import android.content.Context

interface BaseApplication {

    fun getContext(): Context

}