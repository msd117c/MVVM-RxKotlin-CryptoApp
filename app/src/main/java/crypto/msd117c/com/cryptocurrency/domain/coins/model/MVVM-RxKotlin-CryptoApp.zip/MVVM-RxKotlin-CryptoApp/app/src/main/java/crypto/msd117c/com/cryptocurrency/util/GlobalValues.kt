package crypto.msd117c.com.cryptocurrency.util

class GlobalValues {
    companion object {
        var decimalSeparator = ""
        var thousandSeparator = ""
    }
}